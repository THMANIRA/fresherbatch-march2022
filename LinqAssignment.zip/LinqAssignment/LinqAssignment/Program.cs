﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqAssignment
{
    public class Employee
    {
        public int EmployeeID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Title { get; set; }
        public DateTime DOB { get; set; }
        public DateTime DOJ { get; set; }
        public string City { get; set; }
    }
    internal class Program
    {
        public static List<Employee> empList = new List<Employee>
{


 new Employee() {EmployeeID = 1001,FirstName = "Malcolm",LastName = "Daruwalla",Title = "Manager",DOB = DateTime.Parse("1984-01-02"),DOJ = DateTime.Parse("2011-08-09"),City = "Mumbai"},
new Employee() {EmployeeID = 1002,FirstName = "Asdin",LastName = "Dhalla",Title = "AsstManager",DOB = DateTime.Parse("1984-08-20"),DOJ = DateTime.Parse("2012-7-7"),City = "Mumbai"},
new Employee() {EmployeeID = 1003,FirstName = "Madhavi",LastName = "Oza",Title = "Consultant",DOB = DateTime.Parse("1987-11-14"),DOJ = DateTime.Parse("2015-4-12"),City = "Pune"},
new Employee() {EmployeeID = 1004,FirstName = "Saba",LastName = "Shaikh",Title = "SE",DOB = DateTime.Parse("6/3/1990"),DOJ = DateTime.Parse("2/2/2016"),City = "Pune"},
new Employee() {EmployeeID = 1005,FirstName = "Nazia",LastName = "Shaikh",Title = "SE",DOB = DateTime.Parse("3/8/1991"),DOJ = DateTime.Parse("2/2/2016"),City = "Mumbai"},
new Employee() {EmployeeID = 1006,FirstName = "Suresh",LastName = "Pathak",Title = "Consultant",DOB = DateTime.Parse("11/7/1989"),DOJ = DateTime.Parse("8/8/2014"),City = "Chennai"},
new Employee() {EmployeeID = 1007,FirstName = "Vijay",LastName = "Natrajan",Title = "Consultant",DOB = DateTime.Parse("12/2/1989"),DOJ = DateTime.Parse("6/1/2015"),City = "Mumbai"},
new Employee() {EmployeeID = 1008,FirstName = "Rahul",LastName = "Dubey",Title = "Associate",DOB = DateTime.Parse("11/11/1993"),DOJ = DateTime.Parse("11/6/2014"),City = "Chennai"},
new Employee() {EmployeeID = 1009,FirstName = "Amit",LastName = "Mistry",Title = "Associate",DOB = DateTime.Parse("8/12/1992"),DOJ = DateTime.Parse("12/3/2014"),City = "Chennai"},
new Employee() {EmployeeID = 1010,FirstName = "Sumit",LastName = "Shah",Title = "Manager",DOB = DateTime.Parse("4/12/1991"),DOJ = DateTime.Parse("1/2/2016"),City = "Pune"},

};
        static void Main(string[] args)
        {
            DisplayAll();
            Console.WriteLine("-----------");
            NotMumbai();
            Console.WriteLine("------------");
            AsstManager();
            Console.WriteLine("-------------");
            Lastname();
            TotalEmpChennai();
            HighestEmpId();
            Console.ReadKey();
        }
        public static void DisplayAll()
        {
            var emp = from i in empList select i;
            foreach(var Employee in emp)
            //Console.WriteLine(Employee + " ");
            Console.WriteLine(Employee.EmployeeID+" "+Employee.FirstName+" "+Employee.LastName+" "+Employee.Title+" "+Employee.DOB+" "+Employee.DOJ+" "+Employee.City);
        }
        public static void NotMumbai()
        {
            var notMumbai = from i in empList where i.City != "Mumbai" select i;
            foreach(var Employee in notMumbai)
                Console.WriteLine(Employee.EmployeeID + " " + Employee.FirstName + " " + Employee.LastName + " " + Employee.Title + " " + Employee.DOB + " " + Employee.DOJ + " " + Employee.City);
        }
        public static void AsstManager()
        {
            var asstManager = from s in empList
                              where s.Title == "AsstManager"
                              select s;
            foreach(var Employee in asstManager)
                Console.WriteLine(Employee.EmployeeID + " " + Employee.FirstName + " " + Employee.LastName + " " + Employee.Title + " " + Employee.DOB + " " + Employee.DOJ + " " + Employee.City);

        }
        public static void Lastname()
        {
            var lastName = from i in empList where i.LastName.StartsWith("S") select i;
            foreach(var Employee in lastName)
                Console.WriteLine(Employee.EmployeeID + " " + Employee.FirstName + " " + Employee.LastName + " " + Employee.Title + " " + Employee.DOB + " " + Employee.DOJ + " " + Employee.City);
        }
        public static void JoiningDate()
        {
            var joiningDate = from i in empList where i.DOJ <= DateTime.Parse("1/1/2015") select i;
            foreach(var Employee in joiningDate)
            Console.WriteLine(Employee.EmployeeID + " " + Employee.FirstName + " " + Employee.LastName + " " + Employee.Title + " " + Employee.DOB + " " + Employee.DOJ + " " + Employee.City);
        }
        public static void DateOfBirth()
        {
            var dateofBirth = from i in empList where i.DOB >DateTime.Parse("1/1/1990") select i;
            foreach (var Employee in dateofBirth)
                Console.WriteLine(Employee.EmployeeID + " " + Employee.FirstName + " " + Employee.LastName + " " + Employee.Title + " " + Employee.DOB + " " + Employee.DOJ + " " + Employee.City);
        }
        public static void Designation()
        {
            var designation = from i in empList where i.Title.Contains("Consultant") && i.Title.Contains("Associate") select i;
            foreach (var Employee in designation)
                Console.WriteLine(Employee.EmployeeID + " " + Employee.FirstName + " " + Employee.LastName + " " + Employee.Title + " " + Employee.DOB + " " + Employee.DOJ + " " + Employee.City);
        }
        public static void TotalEmp()
        {
            var totalEmp = from i in empList select i;
            Console.WriteLine(totalEmp.Count());
        }
        public static void TotalEmpChennai()
        {
            var totalEmpChennai = from i in empList where i.City== "Chennai" select i;
            Console.WriteLine(totalEmpChennai.Count());
        }
        public static void HighestEmpId()
        {
            var highestEmpId = from i in empList  select i;
            foreach (var Employee in highestEmpId)
                Console.WriteLine(Employee.EmployeeID);

        }
        public static void JoinedAfter()
        {
            var joinedAfter = from i in empList where i.DOJ > DateTime.Parse("1/1/2015") select i;
            Console.WriteLine(joinedAfter.Count());
        }
        public static void NotAssociate()
        {
            var notAssociate = from i in empList where i.Title != "Associate" select i;
            Console.WriteLine(notAssociate.Count());
        }
        public static void EmpCityCOunt()
        {
           var empCityCount1 = from i in empList where i.City == "Mumbai" select i;
            Console.WriteLine("Empoyees from mumbai :"+empCityCount1.Count());
            var empCityount2 = from i in empList where i.City == "Pune" select i;
            Console.WriteLine("Employees from Pune :"+empCityount2.Count());
            var empCityCount3 = from i in empList where i.City == "Chennai" select i;
            Console.WriteLine("Employees from Chennai"+empCityCount3.Count());
        }
        public static void CityTitle()
        {
            
        }


    }//end of Program class
}// end of NameSapace LinqAssignment
